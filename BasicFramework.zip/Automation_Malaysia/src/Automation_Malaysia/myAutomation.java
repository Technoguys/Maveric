package Automation_Malaysia;
    
import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import Mly_Pages.mybasicData_Frontline;
import Mly_Pages.mycreditcard_details_Frontline;
import Mly_Pages.mydocument_Details_frontline;
import Mly_Pages.myemployeeDetails_Frontline;
import Mly_Pages.mypersonal_Details_Frontline;
import Mly_Pages.myreview_Details_Frontline;
import ObjectRepo_sheet.myObjBasicData;   //importing Object repo sheet class of basic data package into myAutomation class 
import Data_Sheet_My.myDatasheet;        //importing Data sheet of MY class into myAutomation class 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utillitiesMalaysia.GenericWrapper;
import utillitiesMalaysia.ProductRepo;
	 
   public class myAutomation {
		

	
		public void NTB_Flow() throws InterruptedException, AWTException, IOException{  
			
//@--------------------------------------------------------------------------@
//@-------------Web Driver Initilization happens hers------------------------@
	  GenericWrapper.Webdriverintilize();
//@------------------------------------------------------------------------- @
			
//@--------------------------------------------------------------------------@
//@-------------Url Selector happens here------------------------------------@
	  GenericWrapper.urlselector();
//@------------------------------------------------------------------------- @
			                
Thread.sleep(6000);
GenericWrapper.captureScreenShot(GenericWrapper.driver);

			
//@--------------------------------------------------------------------------@
//@-------------Url Selector happens here------------------------------------@
			ProductRepo.Product_Selector();
//@------------------------------------------------------------------------- @
			                			
			
//@--------------------------------------------------------------------------@
//@----------------------Bd page call----------------------------------------@
			mybasicData_Frontline.BDpage();
//@------------------------------------------------------------------------- @
            Thread.sleep(5000);
            
//@--------------------------------------------------------------------------@
//@----------------------Personal details page call--------------------------@
		    mypersonal_Details_Frontline.Personal_page();
//@--------------------------------------------------------------------------@		   
			Thread.sleep(4000);

//@--------------------------------------------------------------------------@
//@----------------------Employee details page call--------------------------@
			myemployeeDetails_Frontline.employee_page();
//@--------------------------------------------------------------------------@				
			Thread.sleep(2000);
			
//@----------------------Document details page call--------------------------@
			mydocument_Details_frontline.document_page();
//@--------------------------------------------------------------------------@				
			
//@----------------------Creditcard details page call------------------------@
			mycreditcard_details_Frontline.creditcard_page();
//@--------------------------------------------------------------------------@	
			
//@----------------------Review details page call----------------------------@
			myreview_Details_Frontline.review_page();
//@--------------------------------------------------------------------------@				
		    GenericWrapper.voice();
		
}
		
		
		
		@SuppressWarnings("deprecation")
		public void ETC_Flow() throws InterruptedException, AWTException, IOException{
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\1579666\\Documents\\Automation MY\\jars and chrome driver\\chromedriver.exe");

			WebDriver driver = new ChromeDriver();

			WebDriverWait wait = new WebDriverWait(driver, 60);
			
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        driver.get("https://rcwbsit.sc.com/origination/my-uat/apply.html");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			GenericWrapper.captureScreenShot(driver);
			WebElement LiverpoolFCcashback=driver.findElement(By.xpath("/html/body/section/div/div[1]/section[2]/div/header/a/img"));
	        LiverpoolFCcashback.click();
	        
	        driver.findElement(By.xpath(myObjBasicData.objFullname)).sendKeys(myDatasheet.fullName_ETC);
	     	
	        driver.findElement(By.id(myObjBasicData.objDateofday)).sendKeys(myDatasheet.dateDay_ETC);
	        GenericWrapper.captureScreenShot(driver);
			driver.findElement(By.id(myObjBasicData.objMonthOfBirth)).sendKeys(myDatasheet.dateMonth_ETC);
			
			driver.findElement(By.id(myObjBasicData.objYearOfBirth)).sendKeys(myDatasheet.dateYear_ETC);
			
			driver.findElement(By.id(myObjBasicData.objMobilenumber)).sendKeys(myDatasheet.moblieNumber_ETC);
			
			driver.findElement(By.id(myObjBasicData.objMobilereconfirm)).sendKeys(myDatasheet.moblieNumber_ETC);
			
			driver.findElement(By.id(myObjBasicData.objEmailid)).sendKeys(myDatasheet.emailId_ETC);
			
			driver.findElement(By.id(myObjBasicData.objRecomemail)).sendKeys(myDatasheet.emailId_ETC);
			
		    driver.findElement(By.xpath(myObjBasicData.objResidencyStatus_My)).click();
					
			driver.findElement(By.id(myObjBasicData.objOld_Nric)).sendKeys(myDatasheet.oldNric_ETC);
			GenericWrapper.captureScreenShot(driver);
		    driver.findElement(By.xpath(myObjBasicData.objReview_button_1)).click();
			  
		    ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(0));
				
		    driver.findElement(By.xpath(myObjBasicData.objReview_button_2)).click();
		    driver.switchTo().window(tabs2.get(0));
		    
		    driver.findElement(By.xpath(myObjBasicData.objReview_button_3)).click();
		    driver.switchTo().window(tabs2.get(0));
		    
		    driver.findElement(By.xpath(myObjBasicData.objReview_button_4)).click();
		    driver.switchTo().window(tabs2.get(0));
			
		    driver.findElement(By.xpath(myObjBasicData.objReview_button_5)).click();
		    driver.switchTo().window(tabs2.get(0));
		    GenericWrapper.captureScreenShot(driver);
		    Thread.sleep(1000);
		    driver.findElement(By.id(myObjBasicData.objClientconsent_toggle)).click();
		    driver.findElement(By.xpath(myObjBasicData.objSaveandnext)).click();
			
		    //@--------------------Income details page-----------------------@
		    
		    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//*[@id='credit_limit_consent_a_1']/small")));
		    driver.findElement(By.xpath("//*[@id='credit_limit_consent_a_1']/small")).click();
		    Thread.sleep(2000);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Work type ')]")));
		    driver.findElement(By.xpath("//div[contains(text(),'Work type ')]")).click();
			driver.findElement(By.xpath("//div[contains(text(),'Salaried (Private)')]")).click();
			
			driver.findElement(By.id("name_of_employer_a_1")).sendKeys("Others");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//ul//li[contains(text(),('Others'))]")).click();
			GenericWrapper.captureScreenShot(driver);
			
			driver.findElement(By.id("name_of_employer_other_a_1")).sendKeys("Sai and Kowshik CO");
			
			driver.findElement(By.id("year-years_in_service_a_1")).sendKeys("12");
			
			driver.findElement(By.id("month-years_in_service_a_1")).sendKeys("02");
			
			driver.findElement(By.id("occupation_a_1")).click();
			driver.findElement(By.xpath("//div[contains(text(),('Army'))]")).click();
			
			driver.findElement(By.id("name_of_employer_a_1")).click();
			driver.findElement(By.id("year-years_in_service_a_1")).click();
			
			GenericWrapper.captureScreenShot(driver);
			driver.findElement(By.id("occupation_a_1")).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),('Building Architects'))]")));
			driver.findElement(By.xpath("//div[contains(text(),('Building Architects'))]")).click();
			
			driver.findElement(By.id("nature_of_employer_a_1")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-value='RS04' and contains(text(),('Insurance'))]")));
			driver.findElement(By.xpath("//div[@data-value='RS04' and contains(text(),('Insurance'))]")).click();
			
	        Thread.sleep(2000);
	        GenericWrapper.captureScreenShot(driver);
			driver.findElement(By.xpath("//*[@id='scroll-to-office_phone_number_a_1']/div/div/div[1]")).click();
			driver.findElement(By.xpath("//div[contains(text(),('Malaysia (+60)'))]")).click();
			
			
			
			driver.findElement(By.id("area-office_phone_number_a_1")).sendKeys("121");
			driver.findElement(By.id("no-office_phone_number_a_1")).sendKeys("67856734");
			
			driver.findElement(By.id("off_extension_a_1")).sendKeys("678");
			driver.findElement(By.id("off_email_a_1")).sendKeys("Maveric@sc.com");
			
			driver.findElement(By.name("controlling_interest_a_1")).click();
			
			
			driver.findElement(By.id("off_city_a_1")).sendKeys("chennai");
			
			driver.findElement(By.id("embossed_name_1_p_1")).sendKeys(myDatasheet.fullName_ETC);
			
			GenericWrapper.captureScreenShot(driver);
			WebElement saveAndNextemployement =driver.findElement(By.xpath("//footer//following::span[2]"));
			saveAndNextemployement.click();
		    
			
			
			
			driver.findElement(By.id("card-expiry")).sendKeys(myDatasheet.Cardcardexpiry_ETC);
			
			driver.findElement(By.id("date-of-birth")).sendKeys(myDatasheet.Cardcard_Dateofbirth_ETC);
			
			driver.findElement(By.id("cvv")).sendKeys(myDatasheet.Cardcard_CVV_ETC);
			
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//label[@class='card-number-label']")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[@id='card-number']")).sendKeys(myDatasheet.Creditcard_ETC);
			Thread.sleep(2000);
			GenericWrapper.captureScreenShot(driver);
			driver.findElement(By.xpath("//div[@class='auth-footer authentication-foot']//button[contains(text(),'OK, NEXT')]")).click();
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("otp-input")));
			driver.findElement(By.id("otp-input")).sendKeys(myDatasheet.Cardotp_ETC);
			
			driver.findElement(By.xpath("//button[contains(text(), 'OK, NEXT')]")).click();
			GenericWrapper.captureScreenShot(driver);
			Thread.sleep(9000);
			
			driver.findElement(By.xpath("//footer//following::span[2]")).click();
			
			
			
			
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='1_R0005_null_BD']/div[2]/div[1]/div")).click();
			
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(text(),'3 x Latest Payslip')]")));
			driver.findElement(By.xpath("//div[contains(text(),'6 x Latest 3 months Commission Statement')]")).click();
			
			/*driver.findElement(By.id("upload_1_R0005_null_BD")).click();
	        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(), 'Choose from computer')]")));
			driver.findElement(By.xpath("//label[contains(text(), 'Choose from computer')]")).click();
			Thread.sleep(3000);
			
		
	        uploadFileWithRobot("C:\\Users\\1579666\\Desktop\\SG Doc\\Chrysanthemum.jpg");
			
			driver.findElement(By.xpath("//div[@class='col-xs-4 close-button']")).click();
			*/

			driver.findElement(By.xpath("//footer//following::span[2]")).click();
			Thread.sleep(2000);
			GenericWrapper.captureScreenShot(driver);
			driver.findElement(By.xpath("//span[@class='cross']")).click();
		
			
			//@--------------Credit card details page----@
					Thread.sleep(2000);
					WebElement annualincome = driver.findElement(By.xpath("//span[@class='rz-bar-wrapper']//span[@class='rz-bar']"));
					Actions move = new Actions(driver);
					move.moveToElement(annualincome).clickAndHold().moveByOffset(0,250).release().perform();
					
					driver.findElement(By.id("other_financial_commitments_a_1")).sendKeys("5000");
					
					GenericWrapper.captureScreenShot(driver);
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")));
					driver.findElement(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")).click();
			
					wait.until(ExpectedConditions.textToBePresentInElement(By.xpath("//span[contains(text(),'Please verify your application details')]"), "Please verify your application details"));
					
					String applicationNumber =driver.findElement(By.xpath("//div[@class='desktop-static-info']//span[@class='app-no ng-binding']")).getText();
					System.out.println("Application reference number: "+applicationNumber);
					GenericWrapper.captureScreenShot(driver);
					driver.findElement(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")).click();
					Thread.sleep(3000);
					GenericWrapper.captureScreenShot(driver);
			        GenericWrapper.voice();
	}




	}

	
	


