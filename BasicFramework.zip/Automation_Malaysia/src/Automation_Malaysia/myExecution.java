package Automation_Malaysia;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Scanner;


public class myExecution extends myAutomation {
	
	
	private static Scanner myObj;

	public static void main(String[] args) throws InterruptedException, AWTException, IOException  {
		myExecution Malaysia=new myExecution();
		
		myObj = new Scanner(System.in);  
	    System.out.println("Enter 0 for ETC");
	    System.out.println("Enter 1 for NTB/NTC/ETB");
		
	    int Exe = myObj.nextInt(); 
		
		if(Exe == 1){
		
		Malaysia.NTB_Flow();
		}
		else{
			
		Malaysia.ETC_Flow();
			
		}
		
	}

}

