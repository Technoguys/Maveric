package utillitiesMalaysia;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;






public class GenericWrapper {
	
	public static WebDriver driver = null;
		
static int i=1;
	public static void captureScreenShot(WebDriver driver) throws IOException{
try{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("C:\\Users\\1579666\\Documents\\Screenshot\\Scr'"+i+"'.png"));
		i++;
		}
		catch (IOException e){
			System.out.println(e.getMessage());
		}
}
	
	public static void voice() throws IOException{
		
		Runtime.getRuntime().exec( "cscript C:\\Users\\1579666\\Documents\\AutomationMY\\Application.vbs");
	}
	
	
	public static void uploadFileWithRobot (String imagePath) throws AWTException, InterruptedException {
        StringSelection stringSelection = new StringSelection(imagePath);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
 
        Robot robot =new Robot(); 
        robot.delay(300);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.delay(400);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(150);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(7000);
     
	}		
	
	
	
	public static WebDriver Webdriverintilize(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\1579666\\Documents\\Automation MY\\jars and chrome driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        return driver;
	}
	
	
	
	
	
	
	public static void urlselector(){
		
		GenericWrapper.driver.get("https://rcwbsit.sc.com/origination/my-uat/apply.html");
		GenericWrapper.driver.manage().window().maximize();
	}
	
	
	public static WebDriverWait timewait(){
		
		WebDriverWait wait = new WebDriverWait(GenericWrapper.driver,50);
		return wait;
	}
	
}




