package utillitiesMalaysia;

import org.openqa.selenium.By;

public class ProductRepo {

	public static void Product_Selector(){
		
		GenericWrapper.driver.findElement(By.xpath("/html/body/section/div/div[1]/section[2]/div/header/a/img")).click();
	}
	
	
}
