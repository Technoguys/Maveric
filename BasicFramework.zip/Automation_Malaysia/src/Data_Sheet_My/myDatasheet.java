package Data_Sheet_My;

public class myDatasheet {
	/* @--------- NTB/NTC/ETB----Basic Data Page------------------------------@
    Class Name: myDatasheet
    Description: Maintained as a data table sheet.
    Syntax to be used in another class: myDatasheet.varilablename
    Author: Kowshik
    ------------------------------------------------------------------------*/
	
	
    public static String fullName= "kowshik shanmugasundaram";
    
    public static String dateDay = "01";

    public static String dateMonth = "01";

    public static String dateYear = "1989";

    public static String moblieNumber = "88005575";

    public static String emailId = "TDMLothar@dummydomain.com";

    public static String oldNric ="871004905400";
    
    
    /* @----------------ETC----Basic Data Page------------------------------@
    Class Name: myDatasheet
    Description: Maintained as a data table sheet.
    Syntax to be used in another class: myDatasheet.varilablename
    Author: Kowshik
    ------------------------------------------------------------------------*/
    
    public static String fullName_ETC= "TDMMonique TDMTenardier";
    
    public static String dateDay_ETC = "19";

    public static String dateMonth_ETC = "01";

    public static String dateYear_ETC = "1985";

    public static String moblieNumber_ETC = "11999005257";

    public static String emailId_ETC = "TDMMonique.7355@sc.com";

    public static String oldNric_ETC ="871004912430";
    
    public static String Creditcard_ETC="5404786540352379";
    
    public static String s=dateYear_ETC;
    
    public static String a =s.substring(2, s.length()); 
    
    
    public static String Cardcardexpiry_ETC= dateMonth_ETC+a;
    
    public static String Cardcard_Dateofbirth_ETC= dateDay_ETC+dateMonth_ETC+dateYear_ETC;

    public static String Cardcard_CVV_ETC ="123";
    
    public static String Cardotp_ETC="123456";

	
	
}

	


