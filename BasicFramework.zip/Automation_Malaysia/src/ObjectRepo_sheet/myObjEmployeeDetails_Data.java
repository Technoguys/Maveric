package ObjectRepo_sheet;

public class myObjEmployeeDetails_Data {
	
	public static String objWorktypeDRP="work_type_a_1";
	
	public static String objEmployeeWorktype="//div[contains(text(),'Salaried (Private)')]";
	
	public static String objNatureofEmployer="name_of_employer_a_1";
	
	
	
	

}
