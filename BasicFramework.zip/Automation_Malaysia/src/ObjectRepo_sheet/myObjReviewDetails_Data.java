package ObjectRepo_sheet;

public class myObjReviewDetails_Data {
	
public static String referenceReview="";


}
