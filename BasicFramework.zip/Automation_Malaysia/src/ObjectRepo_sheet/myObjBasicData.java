package ObjectRepo_sheet;



public class myObjBasicData {
	
	/* @-----------------------Contains Objects of Basic Data Page------------------------------@
    Class Name: myObjBasicdata
    Description: Maintained as a Object repo file for Basic data sheet
    Syntax to be used in another class: myObjBasicdata.varilablename
    Author: Kowshik
    -------------------------------------------------------------------------------------------*/
	
	
	public static String objFullname = "//*[@id='full_name_a_1']";

	public static String objDateofday = "date-date_of_birth_a_1";

	public static String objMonthOfBirth="month-date_of_birth_a_1";

	public static String objYearOfBirth="year-date_of_birth_a_1";

	public static String objMobilenumber="mobile_number_a_1";

	public static String objMobilereconfirm="reconfirm_mobile_number_a_1";

	public static String objEmailid="email_a_1";

	public static String objRecomemail ="email_1_a_1";

	public static String objResidencyStatus_My="//label[@id='residency_status_a_1_CT']";

	public static String objOld_Nric="NRIC_a_1";

	public static String objReview_button_1="//*[@id='consent-review-client_consent_12']/a";

	public static String objReview_button_2="//*[@id='consent-review-client_consent_13']/a";

	public static String objReview_button_3="//*[@id='consent-review-client_consent_18']/a";

	public static String objReview_button_4="//*[@id='consent-review-client_consent_22']/a";

	public static String objReview_button_5="//*[@id='consent-review-client_consent_23']/a";

	public static String objClientconsent_toggle="client_consent_25_a_1";

	public static String objSaveandnext ="//footer//following::span[2]";

}
