package ObjectRepo_sheet;

public class myObjCreditcard_Data {
	
	public static String objAnnualincome="//span[@class='rz-bar-wrapper']//span[@class='rz-bar']";
	public static String objFinancialcommitments ="other_financial_commitments_a_1";
	public static String objEmbossed_name="embossed_name_p_1";
	
	
	

}
