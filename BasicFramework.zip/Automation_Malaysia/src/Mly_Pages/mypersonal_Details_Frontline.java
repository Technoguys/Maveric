package Mly_Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utillitiesMalaysia.GenericWrapper;

public class mypersonal_Details_Frontline {
	
	public static void Personal_page() throws IOException, InterruptedException{
		
		GenericWrapper.driver.findElement(By.id("resident_status_a_1")).click();
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Resident - Bumiputra'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("country_of_birth_a_1")).click();
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Malaysia'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("gender_a_1")).click();
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Male'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("marital_status_a_1")).click();
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Single'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("ethnicity_a_1")).click();
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Malay/Bumiputra'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("education_level_a_1")).click();
		Thread.sleep(1000);
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('University Degree'))]")).click();
		
		GenericWrapper.driver.findElement(By.id("area-home_phone_number_a_1")).sendKeys("001");
		GenericWrapper.driver.findElement(By.id("no-home_phone_number_a_1")).sendKeys("678283782");
		Thread.sleep(1000);
		GenericWrapper.captureScreenShot(GenericWrapper.driver);
		
		GenericWrapper.driver.findElement(By.id("other_alias_a_1")).click();
		GenericWrapper.driver.findElement(By.id("alias_1_a_1")).sendKeys("kowshik sai");
		GenericWrapper.driver.findElement(By.id("res_address_line_1_a_1")).sendKeys("Sai street");
		GenericWrapper.driver.findElement(By.id("res_address_line_2_a_1")).sendKeys("kowshik street");
		GenericWrapper.driver.findElement(By.id("res_address_line_3_a_1")).sendKeys("Ajay street");
	    
		GenericWrapper.driver.findElement(By.id("res_city_a_1")).sendKeys("Chennai");
	   
		GenericWrapper.driver.findElement(By.id("selectbox-res_state_a_1-selectized")).click();
	    
		Thread.sleep(500);
	    
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),'Pahang')]")).click();
	    
		GenericWrapper.driver.findElement(By.id("res_postal_code_a_1")).sendKeys("27150");
	    
		GenericWrapper.driver.findElement(By.id("years_at_address_a_1")).click();
	    
	    Thread.sleep(500);
	    
	    GenericWrapper.driver.findElement(By.xpath("//div[@class='option' and contains(text(),5)]")).click();
	    
	    GenericWrapper.driver.findElement(By.xpath("//div[@class='dummy-input' and contains(text(),'Ownership status')]")).click();
	    Thread.sleep(500);
	    
	    GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Owned'))]")).click();
	    
	    GenericWrapper.captureScreenShot(GenericWrapper.driver);
	    
	    WebElement saveAndNextElem=GenericWrapper.driver.findElement(By.xpath("//footer//following::span[2]"));
		
	    saveAndNextElem.click();
		
	}
	

}
