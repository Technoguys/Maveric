package Mly_Pages;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;

import utillitiesMalaysia.GenericWrapper;
import Data_Sheet_My.myDatasheet;
import ObjectRepo_sheet.myObjBasicData;



public class mybasicData_Frontline  {
	
	public static void BDpage() throws IOException, InterruptedException{
		
	GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objFullname)).sendKeys(myDatasheet.fullName);
    GenericWrapper.captureScreenShot(GenericWrapper.driver);
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objDateofday)).sendKeys(myDatasheet.dateDay);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objMonthOfBirth)).sendKeys(myDatasheet.dateMonth);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objYearOfBirth)).sendKeys(myDatasheet.dateYear);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objMobilenumber)).sendKeys(myDatasheet.moblieNumber);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objMobilereconfirm)).sendKeys(myDatasheet.moblieNumber);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objEmailid)).sendKeys(myDatasheet.emailId);
	
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objRecomemail)).sendKeys(myDatasheet.emailId);
	
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objResidencyStatus_My)).click();
			
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objOld_Nric)).sendKeys(myDatasheet.oldNric);

	GenericWrapper.captureScreenShot(GenericWrapper.driver);
	GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objReview_button_1)).click();
	  
    ArrayList<String> tabs2 = new ArrayList<String> (GenericWrapper.driver.getWindowHandles());
    GenericWrapper.driver.switchTo().window(tabs2.get(0));
		
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objReview_button_2)).click();
    GenericWrapper.driver.switchTo().window(tabs2.get(0));
    
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objReview_button_3)).click();
    GenericWrapper.driver.switchTo().window(tabs2.get(0));
    
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objReview_button_4)).click();
    GenericWrapper.driver.switchTo().window(tabs2.get(0));
	
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objReview_button_5)).click();
    GenericWrapper.driver.switchTo().window(tabs2.get(0));
    
    GenericWrapper.captureScreenShot(GenericWrapper.driver);
	
    Thread.sleep(1000);
    
    GenericWrapper.driver.findElement(By.id(myObjBasicData.objClientconsent_toggle)).click();
    GenericWrapper.driver.findElement(By.xpath(myObjBasicData.objSaveandnext)).click();
	
	
	}
}

