package Mly_Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utillitiesMalaysia.GenericWrapper;

public class myreview_Details_Frontline {
	
	
	@SuppressWarnings("deprecation")
	public static void review_page() throws IOException, InterruptedException{
	//@----------------Review Page---------------@
	Thread.sleep(50000);
	GenericWrapper.timewait().until(ExpectedConditions.textToBePresentInElement(By.xpath("//span[contains(text(),'Please verify your application details')]"), "Please verify your application details"));
	
	String applicationNumber =GenericWrapper.driver.findElement(By.xpath("//div[@class='desktop-static-info']//span[@class='app-no ng-binding']")).getText();
	System.out.println("Application reference number: "+applicationNumber);
	Thread.sleep(2000);
	GenericWrapper.captureScreenShot(GenericWrapper.driver);
	GenericWrapper.Webdriverintilize().findElement(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")).click();
	Thread.sleep(3000);
	GenericWrapper.captureScreenShot(GenericWrapper.driver);
	
	}	

}
