package Mly_Pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utillitiesMalaysia.GenericWrapper;

public class mydocument_Details_frontline {

	public static void document_page() throws IOException, InterruptedException, AWTException{
		
		//@---------------NRIC upload----------------@
		GenericWrapper.driver.findElement(By.id("upload_1_R0001_null_BD")).click();
		GenericWrapper.timewait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(), 'Choose from computer')]")));
		GenericWrapper.driver.findElement(By.xpath("//label[contains(text(), 'Choose from computer')]")).click();
		Thread.sleep(3000);
		GenericWrapper.uploadFileWithRobot("C:\\Users\\1579666\\Desktop\\SG Doc\\Chrysanthemum.jpg");
		GenericWrapper.driver.findElement(By.xpath("//div[@class='col-xs-4 close-button']")).click();
		
		//@---------------Income Document upload----------------@
		
		Thread.sleep(2000);
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),'Income Document 1 ')]")).click();
		GenericWrapper.timewait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(text(),'3 x Latest Payslip')]")));
		GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),'3 x Latest Payslip')]")).click();
		GenericWrapper.driver.findElement(By.id("upload_1_R0005_1_BD")).click();
		GenericWrapper.timewait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(), 'Choose from computer')]")));
		GenericWrapper.driver.findElement(By.xpath("//label[contains(text(), 'Choose from computer')]")).click();
		Thread.sleep(3000);
	    GenericWrapper.uploadFileWithRobot("C:\\Users\\1579666\\Desktop\\SG Doc\\Chrysanthemum.jpg");
	    GenericWrapper.driver.findElement(By.xpath("//div[@class='col-xs-4 close-button']")).click();
		
		//@---------------Bank statement Document upload----------------@
		Thread.sleep(1500);
		
		GenericWrapper.driver.findElement(By.id("upload_1_R0005_2_BD")).click();
		GenericWrapper.timewait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(), 'Choose from computer')]")));
		GenericWrapper.driver.findElement(By.xpath("//label[contains(text(), 'Choose from computer')]")).click();
		Thread.sleep(2000);
		GenericWrapper.uploadFileWithRobot("C:\\Users\\1579666\\Desktop\\SG Doc\\Chrysanthemum.jpg");
		GenericWrapper.driver.findElement(By.xpath("//div[@class='col-xs-4 close-button']")).click();
		
		//@--------------Save and next---------------@
		Thread.sleep(1000);
		GenericWrapper.captureScreenShot(GenericWrapper.Webdriverintilize());
		GenericWrapper.timewait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")));
		GenericWrapper.driver.findElement(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")).click();
		
		
		
		
		
	}
	
	
}
