package Mly_Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import ObjectRepo_sheet.myObjCreditcard_Data;
import utillitiesMalaysia.GenericWrapper;

public class mycreditcard_details_Frontline {

	
	public static void creditcard_page() throws InterruptedException, IOException{
	//@--------------Credit card details page----@
			Thread.sleep(2000);
			WebElement annualincome = GenericWrapper.driver.findElement(By.xpath(myObjCreditcard_Data.objAnnualincome));
			Actions move = new Actions(GenericWrapper.driver);
			move.moveToElement(annualincome).clickAndHold().moveByOffset(0,250).release().perform();
			
			GenericWrapper.driver.findElement(By.id(myObjCreditcard_Data.objEmbossed_name)).sendKeys("5000");
			GenericWrapper.driver.findElement(By.id(myObjCreditcard_Data.objEmbossed_name)).sendKeys("TDMLothar");
			
			Thread.sleep(2000);
			GenericWrapper.captureScreenShot(GenericWrapper.driver);
			GenericWrapper.timewait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")));
			GenericWrapper.driver.findElement(By.xpath("//div[@class='oknext-btn btn-approved']//footer//following::span[2]")).click();
	
	
	}
	
}
