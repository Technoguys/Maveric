package Mly_Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import ObjectRepo_sheet.myObjEmployeeDetails_Data;
import utillitiesMalaysia.GenericWrapper;

public class myemployeeDetails_Frontline {

	public static void employee_page() throws IOException, InterruptedException{
		
	GenericWrapper.timewait().until(ExpectedConditions.visibilityOfElementLocated(By.id(myObjEmployeeDetails_Data.objWorktypeDRP)));
	GenericWrapper.driver.findElement(By.id(myObjEmployeeDetails_Data.objWorktypeDRP)).click();
	GenericWrapper.driver.findElement(By.xpath(myObjEmployeeDetails_Data.objEmployeeWorktype)).click();
	GenericWrapper.driver.findElement(By.id(myObjEmployeeDetails_Data.objNatureofEmployer)).sendKeys("Others");
	Thread.sleep(2000);
	GenericWrapper.driver.findElement(By.xpath("//ul//li[contains(text(),('Others'))]")).click();
	
	GenericWrapper.driver.findElement(By.id("name_of_employer_other_a_1")).sendKeys("Sai and Kowshik CO");
	
	GenericWrapper.driver.findElement(By.id("year-years_in_service_a_1")).sendKeys("12");
	
	GenericWrapper.driver.findElement(By.id("month-years_in_service_a_1")).sendKeys("02");
	
	GenericWrapper.driver.findElement(By.id("name_of_employer_a_1")).click();
	GenericWrapper.driver.findElement(By.id("year-years_in_service_a_1")).click();
	
	GenericWrapper.captureScreenShot(GenericWrapper.driver);
	
	GenericWrapper.driver.findElement(By.id("occupation_a_1")).click();
	GenericWrapper.timewait().until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),('Building Architects'))]")));
	GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Building Architects'))]")).click();
	GenericWrapper.driver.findElement(By.id("nature_of_employer_a_1")).click();
	GenericWrapper.timewait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-value='RS04' and contains(text(),('Insurance'))]")));
	GenericWrapper.driver.findElement(By.xpath("//div[@data-value='RS04' and contains(text(),('Insurance'))]")).click();
	
    Thread.sleep(2000);
    GenericWrapper.driver.findElement(By.xpath("//*[@id='scroll-to-office_phone_number_a_1']/div/div/div[1]")).click();
    GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Malaysia (+60)'))]")).click();
	
	
	
    GenericWrapper.driver.findElement(By.id("area-office_phone_number_a_1")).sendKeys("121");
    GenericWrapper.driver.findElement(By.id("no-office_phone_number_a_1")).sendKeys("67856734");
	
    GenericWrapper.driver.findElement(By.id("off_extension_a_1")).sendKeys("678");
    GenericWrapper.driver.findElement(By.id("off_email_a_1")).sendKeys("sai@sc.com");
	
    GenericWrapper.driver.findElement(By.name("controlling_interest_a_1")).click();
	
    GenericWrapper.driver.findElement(By.id("off_address_line_1_a_1")).sendKeys("Bakers street");
    GenericWrapper.driver.findElement(By.id("off_address_line_2_a_1")).sendKeys("Chetpet");
    GenericWrapper.driver.findElement(By.id("off_city_a_1")).sendKeys("chennai");
	
    GenericWrapper.timewait().until(ExpectedConditions.visibilityOfElementLocated(By.id("selectbox-off_state_a_1-selectized")));
    GenericWrapper.driver.findElement(By.id("selectbox-off_state_a_1-selectized")).click();
	GenericWrapper.timewait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),('Pahang'))]")));
	GenericWrapper.driver.findElement(By.xpath("//div[contains(text(),('Pahang'))]")).click();
	
	GenericWrapper.driver.findElement(By.id("off_postal_code_a_1")).sendKeys("27150");

	GenericWrapper.captureScreenShot(GenericWrapper.driver);
	Thread.sleep(2000);
	WebElement saveAndNextemployement =GenericWrapper.driver.findElement(By.xpath("//footer//following::span[2]"));
	saveAndNextemployement.click();
	
	
	
	}
}
